def sum(a,b):
    result = a + b
    return result

def subtraction(a,b):
    result = a - b
    return result

def multiply(a, b):
    result = a * b
    return result

def divide1(a, b):
    result = a / b
    return result

def divide2(a, b):
    result = a // b
    return result

def remainder(a,b):
    result = a % b
    return result

def pow(a,b):
    result = a ** b
    return result

def sqrt(a):
    result = a * 1/2
    return result

def percent(a,b):
    result = a / 100 * b
    return result